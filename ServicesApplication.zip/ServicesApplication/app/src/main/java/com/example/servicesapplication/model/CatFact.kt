package com.example.servicesapplication.model

data class CatFact(
    val fact: String,
    val length: Int
)
