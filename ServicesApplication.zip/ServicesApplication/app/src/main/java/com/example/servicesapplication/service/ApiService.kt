package com.example.servicesapplication.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.URL
import com.example.servicesapplication.model.CatFact

class ApiService : Service() {
    private val url = "https://catfact.ninja/facts?limit=10"

    private val broadcastIntent = Intent("com.example.servicesapplication")

    private fun getCatFacts() {
        Thread {
            var catFacts: List<CatFact> = emptyList()
            try {
                val url = URL(url)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 1000
                val response = connection.inputStream.bufferedReader().readText()
                connection.disconnect()
                val json = Gson().fromJson(response, Map::class.java)
                catFacts = (json["data"] as List<Map<String, Any>>).map {
                    CatFact(
                        fact = it["fact"] as String,
                        length = (it["length"] as Double).toInt()
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            broadcastIntent.putExtra("catFacts", Gson().toJson(catFacts))
            sendBroadcast(broadcastIntent)
        }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getCatFacts()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}